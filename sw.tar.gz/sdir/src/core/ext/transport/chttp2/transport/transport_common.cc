//
//
// Copyright 2025 gRPC authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//

#include "src/core/ext/transport/chttp2/transport/transport_common.h"

#include <cstdint>

#include "src/core/util/shared_bit_gen.h"
#include "src/core/util/time.h"
#include "absl/random/random.h"

namespace grpc_core {

Duration TarpitDuration(const int min_tarpit_duration_ms,
                        const int max_tarpit_duration_ms) {
  if (min_tarpit_duration_ms > max_tarpit_duration_ms) {
    return Duration::Milliseconds(min_tarpit_duration_ms);
  }
  return Duration::Milliseconds(absl::LogUniform<int>(
      SharedBitGen(), min_tarpit_duration_ms, max_tarpit_duration_ms));
}

}  // namespace grpc_core
